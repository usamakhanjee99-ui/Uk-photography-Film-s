UK Photography & Films — اردو ہدایات

آپ کی دی گئی رابطے کی تفصیلات شامل کر دی گئی ہیں:
WhatsApp: 03150107840
Email: Usamakhanjee99@gmail.com

مفت شائع کرنے کا طریقہ:
1. https://github.com پر اکاؤنٹ بنائیں یا سائن اِن کریں۔
2. New repository پر جائیں اور repository کا نام اپنے GitHub username کے مطابق username.github.io رکھیں۔
3. Public منتخب کریں اور Create repository دبائیں۔
4. Add file > Upload files منتخب کریں۔
5. ZIP فائل کو پہلے اپنے موبائل میں Extract کریں؛ پھر اس کے اندر موجود index.html اپ لوڈ کریں (فائل repository کی جڑ/root میں ہو)۔
6. Commit changes دبائیں۔
7. Settings > Pages میں جائیں۔
8. Build and deployment میں Source کے لیے Deploy from a branch منتخب کریں۔
9. Branch میں main اور folder میں /(root) منتخب کرکے Save دبائیں۔
10. چند منٹ انتظار کریں، پھر https://YOUR-USERNAME.github.io کھولیں۔ YOUR-USERNAME کی جگہ اپنا GitHub username لکھیں۔

سرکاری رہنمائی: https://docs.github.com/en/pages/quickstart
نوٹ: ویب سائٹ میں آپ کا نمبر بین الاقوامی WhatsApp لنک (923150107840) کے طور پر استعمال ہے۔
یہ ویب سائٹ static ہے؛ خودکار بکنگ/ادائیگی یا حقیقی آن لائن فوٹو ایڈیٹنگ ٹول ابھی شامل نہیں۔
